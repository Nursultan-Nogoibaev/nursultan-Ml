# Практическая работа №5 — Классификация и метрики

**Студент:** Нурсултан Ногойбаев Таалайбекович  
**Группа:** CS 32-24

## Цель работы
Построить логистическую регрессию для прогнозирования оттока клиентов, изучить матрицу ошибок, ROC-AUC, Precision и Recall, сравнить пороги классификации.

## Структура проекта
```text
ML-P-5-churn_classification/
├── notebooks/
│   └── churn_classification.ipynb
├── .gitignore
├── README.md
└── requirements.txt
```

## Запуск
```bash
git clone <ссылка-на-ваш-репозиторий>
cd ML-P-5-churn_classification
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS / Linux:
```bash
source .venv/bin/activate
```

Установка библиотек и запуск:
```bash
pip install -r requirements.txt
jupyter notebook notebooks/churn_classification.ipynb
```

## Примечание
Ноутбук содержит код, пояснения и проверки. После запуска всех ячеек фактические метрики и графики будут рассчитаны на используемой версии библиотек.
