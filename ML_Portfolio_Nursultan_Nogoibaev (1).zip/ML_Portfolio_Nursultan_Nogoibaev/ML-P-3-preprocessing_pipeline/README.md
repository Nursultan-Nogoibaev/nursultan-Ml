# Практическая работа №3 — Pipeline и ColumnTransformer

**Студент:** Нурсултан Ногойбаев Таалайбекович  
**Группа:** CS 32-24

## Цель работы
Построить воспроизводимый конвейер подготовки данных: заполнить пропуски, масштабировать числовые признаки и закодировать категориальные признаки.

## Структура проекта
```text
ML-P-3-preprocessing_pipeline/
├── notebooks/
│   └── preprocessing_pipeline.ipynb
├── .gitignore
├── README.md
└── requirements.txt
```

## Запуск
```bash
git clone <ссылка-на-ваш-репозиторий>
cd ML-P-3-preprocessing_pipeline
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS / Linux:
```bash
source .venv/bin/activate
```

Установка библиотек и запуск:
```bash
pip install -r requirements.txt
jupyter notebook notebooks/preprocessing_pipeline.ipynb
```

## Примечание
Ноутбук содержит код, пояснения и проверки. После запуска всех ячеек фактические метрики и графики будут рассчитаны на используемой версии библиотек.
