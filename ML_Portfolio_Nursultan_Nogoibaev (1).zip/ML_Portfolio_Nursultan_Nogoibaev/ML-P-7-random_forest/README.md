# Практическая работа №7 — Случайный лес и подбор параметров

**Студент:** Нурсултан Ногойбаев Таалайбекович  
**Группа:** CS 32-24

## Цель работы
Сравнить дерево решений и случайный лес для прогноза чаевых, подобрать гиперпараметры через GridSearchCV, исследовать важность признаков и проверить сокращённый набор факторов.

## Структура проекта
```text
ML-P-7-random_forest/
├── notebooks/
│   └── random_forest.ipynb
├── .gitignore
├── README.md
└── requirements.txt
```

## Запуск
```bash
git clone <ссылка-на-ваш-репозиторий>
cd ML-P-7-random_forest
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS / Linux:
```bash
source .venv/bin/activate
```

Установка библиотек и запуск:
```bash
pip install -r requirements.txt
jupyter notebook notebooks/random_forest.ipynb
```

## Примечание
Ноутбук содержит код, пояснения и проверки. После запуска всех ячеек фактические метрики и графики будут рассчитаны на используемой версии библиотек.
