# Практическая работа №2 — EDA датасета Titanic

**Студент:** Нурсултан Ногойбаев Таалайбекович  
**Группа:** CS 32-24

## Цель работы
Провести разведочный анализ пассажиров Титаника: изучить структуру, пропуски, распределение целевого признака, выбросы и взаимосвязи признаков.

## Структура проекта
```text
ML-P-2-titanic_eda/
├── notebooks/
│   └── titanic_eda.ipynb
├── .gitignore
├── README.md
└── requirements.txt
```

## Запуск
```bash
git clone <ссылка-на-ваш-репозиторий>
cd ML-P-2-titanic_eda
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS / Linux:
```bash
source .venv/bin/activate
```

Установка библиотек и запуск:
```bash
pip install -r requirements.txt
jupyter notebook notebooks/titanic_eda.ipynb
```

## Примечание
Ноутбук содержит код, пояснения и проверки. После запуска всех ячеек фактические метрики и графики будут рассчитаны на используемой версии библиотек.
