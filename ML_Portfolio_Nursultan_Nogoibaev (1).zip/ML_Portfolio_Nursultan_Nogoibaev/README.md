# Учебный ML-портфель

**Студент:** Нурсултан Ногойбаев Таалайбекович  
**Группа:** CS 32-24

В архив входят практические работы №1–7 по анализу данных и машинному обучению.

| Работа | Тема | Папка |
|---|---|---|
| 1 | EDA ресторанного датасета Tips | `ML-P-1-tips_eda` |
| 2 | EDA Titanic | `ML-P-2-titanic_eda` |
| 3 | Подготовка данных: Pipeline и ColumnTransformer | `ML-P-3-preprocessing_pipeline` |
| 4 | Линейная регрессия | `ML-P-4-linear_regression` |
| 5 | Классификация оттока клиентов | `ML-P-5-churn_classification` |
| 6 | NLP: классификация текстов | `ML-P-6-text_classification` |
| 7 | Random Forest и GridSearchCV | `ML-P-7-random_forest` |

Каждый проект содержит Jupyter Notebook, README с инструкцией запуска, `requirements.txt` и `.gitignore`.

## Общие требования
Python 3.10+ рекомендуется. Для каждого проекта создавайте отдельное виртуальное окружение или используйте одно общее.
