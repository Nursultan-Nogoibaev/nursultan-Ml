# ПР-1. Linux и терминал

Цель — освоить базовые команды и подготовить окружение. Выполнить в Ubuntu:

```bash
whoami; pwd; uname -a; lsb_release -a
mkdir -p ~/os-course/pr01 && cd ~/os-course/pr01
echo "Меня зовут Нурсултан" > about.txt
echo "Я изучаю Linux" >> about.txt
cat about.txt
ls -la
sudo apt update && sudo apt install -y git python3 build-essential
```

В `ls -la`: первый столбец — тип и права; второй — число ссылок; третий — владелец; четвёртый — группа; пятый — размер; шестой — дата изменения; последний — имя.

Дополнительно (вариант B):
```bash
sudo groupadd developers
sudo adduser student2
sudo usermod -aG developers student2
sudo mkdir -p /srv/shared
sudo chown root:developers /srv/shared
sudo chmod 2775 /srv/shared
sudo -u student2 touch /srv/shared/test.txt
```

`su` переключает пользователя, а `sudo` запускает отдельную команду с другими правами. Root обычно заблокирован для обычного входа, чтобы не работать постоянно с полными правами. `2775` включает setgid: новые файлы наследуют группу каталога. Удаление файла зависит от прав на каталог.

Добавить в `~/.bashrc`: `alias ll='ls -la'`, `alias c='clear'`, `export COURSE_NAME='OS course'`; применить `source ~/.bashrc`.

**Вывод:** познакомился с командами, файлами, пользователями и правами Linux.
