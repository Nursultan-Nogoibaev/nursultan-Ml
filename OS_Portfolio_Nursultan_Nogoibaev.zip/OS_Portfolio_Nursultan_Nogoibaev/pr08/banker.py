import sys
def read_state(path):
 available=None; alloc={}; maximum={}
 for line in open(path,encoding="utf-8"):
  s=line.strip()
  if not s: continue
  if s.startswith("#"):
   if "Available" in s: available=list(map(int,s.split()[2:5]))
   continue
  p=s.split(); alloc[p[0]]=list(map(int,p[1:4])); maximum[p[0]]=list(map(int,p[4:7]))
 return available,alloc,maximum
def safe(available,alloc,maximum):
 work=available[:]; done=set(); order=[]
 need={p:[maximum[p][i]-alloc[p][i] for i in range(3)] for p in alloc}
 changed=True
 while changed:
  changed=False
  for p in alloc:
   if p not in done and all(need[p][i]<=work[i] for i in range(3)):
    work=[work[i]+alloc[p][i] for i in range(3)]; done.add(p); order.append(p); changed=True
 return order if len(done)==len(alloc) else None
if len(sys.argv)!=2: raise SystemExit("Использование: python3 banker.py bank1.txt")
avail,alloc,maximum=read_state(sys.argv[1]); result=safe(avail,alloc,maximum)
print("SAFE" if result else "UNSAFE")
if result: print("Безопасная последовательность:"," -> ".join(result))
