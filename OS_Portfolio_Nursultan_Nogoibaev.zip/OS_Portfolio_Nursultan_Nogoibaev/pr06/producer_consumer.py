import queue, threading, time
q=queue.Queue(maxsize=5); done=object(); received=[]
def producer():
 for n in range(20): q.put(n)
 q.put(done)
def consumer():
 while True:
  x=q.get()
  if x is done: q.task_done(); break
  received.append(x); q.task_done(); time.sleep(0.01)
p=threading.Thread(target=producer); c=threading.Thread(target=consumer)
p.start(); c.start(); p.join(); c.join()
assert sorted(received)==list(range(20))
print("Получено элементов:",len(received))
