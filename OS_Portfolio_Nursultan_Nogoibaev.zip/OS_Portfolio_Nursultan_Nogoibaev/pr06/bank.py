import threading
a=b=1000
lock=threading.Lock()
def transfer(reverse):
 global a,b
 for _ in range(10000):
  with lock:
   if reverse: b-=1; a+=1
   else: a-=1; b+=1
   assert a+b==2000
ts=[threading.Thread(target=transfer,args=(False,)),threading.Thread(target=transfer,args=(True,))]
for t in ts: t.start()
for t in ts: t.join()
print("Счета:",a,b,"сумма:",a+b)
