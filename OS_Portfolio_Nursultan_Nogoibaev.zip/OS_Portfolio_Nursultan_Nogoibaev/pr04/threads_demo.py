import threading, time
counter = 0
def worker():
    global counter
    for _ in range(100_000): counter += 1
threads = [threading.Thread(target=worker) for _ in range(4)]
start = time.perf_counter()
for t in threads: t.start()
for t in threads: t.join()
print("Counter:", counter, "expected:", 400_000)
print("Time:", round(time.perf_counter()-start, 4), "sec")
