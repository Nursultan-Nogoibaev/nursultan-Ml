import os
r,w=os.pipe(); pid=os.fork()
if pid==0:
 os.close(r); os.write(w,"Сообщение от ребёнка".encode()); os.close(w); os._exit(0)
else:
 os.close(w); data=os.read(r,1024); os.close(r); os.waitpid(pid,0); print(data.decode())
