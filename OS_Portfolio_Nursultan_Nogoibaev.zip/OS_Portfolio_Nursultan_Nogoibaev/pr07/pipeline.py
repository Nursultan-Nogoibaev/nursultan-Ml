import subprocess
p=subprocess.Popen(["ls"],stdout=subprocess.PIPE,text=True)
r=subprocess.run(["grep","py"],stdin=p.stdout,capture_output=True,text=True)
p.stdout.close(); p.wait(); print(r.stdout,end="")
