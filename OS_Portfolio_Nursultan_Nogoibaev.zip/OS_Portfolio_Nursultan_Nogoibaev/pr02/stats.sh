#!/bin/bash
DIR="${1:-data}"
if [ ! -d "$DIR" ]; then echo "Каталог не найден: $DIR"; exit 1; fi
total=0; best=""; best_count=0
for f in "$DIR"/*.log; do
  [ -e "$f" ] || continue
  count=$(grep -c "ERROR" "$f")
  echo "$(basename "$f"): $count ошибок"
  total=$((total + count))
  if [ "$count" -gt "$best_count" ]; then best_count=$count; best=$(basename "$f"); fi
done
echo "Всего ошибок: $total"
echo "Больше всего: $best ($best_count)"
